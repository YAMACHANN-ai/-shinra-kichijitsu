import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const root = new URL('../web/', import.meta.url);
const read = name => fs.readFileSync(new URL(name, root), 'utf8');
const html = read('index.html');
for (const m of html.matchAll(/<script>([\s\S]*?)<\/script>/g)) new vm.Script(m[1]);
new vm.Script(read('sw.js'));
const manifest = JSON.parse(read('manifest.webmanifest'));
for (const icon of manifest.icons) assert(fs.existsSync(new URL(icon.src,root)));
assert(fs.existsSync(new URL(manifest.start_url,root)));
for (const id of ['grid','month','modal','detail','savedList','restoreFile']) assert(html.includes(`id="${id}"`));
const rowsText = html.match(/const rows=\[([\s\S]*?)\];/);
assert(rowsText,'calendar data');
const rows = vm.runInNewContext('['+rowsText[1]+']');
assert.equal(rows.length,14);
for (let i=0;i<rows.length;i++) {
  const [y,m,...groups]=rows[i]; const expected=new Date(Date.UTC(2026,10+i,1));
  assert.equal(y,expected.getUTCFullYear()); assert.equal(m,expected.getUTCMonth()+1);
  const last=new Date(Date.UTC(y,m,0)).getUTCDate();
  for (const g of groups) { assert.equal(new Set(g).size,g.length); for (const d of g) assert(Number.isInteger(d)&&d>=1&&d<=last); }
}
console.log('OK: JavaScript, manifest, icons, required UI, 14 calendar months.');
