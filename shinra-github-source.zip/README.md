# 森羅万象・開運吉日暦｜GitHub ビルド指示書

対象：前回のアプリ版（2026年11月〜2027年12月）
配布物：`shinra-github-source.zip`（展開して使用）

## 1. ビルド方針

- Android：GitHub Actions で APK を生成。Android 8.0（API 26）以上を対象とする。
- iPhone・Android・PC：GitHub Pages で HTTPS の Web アプリ（PWA）を公開。
- 両版のカレンダーは `web/index.html` を共通ソースにする。Node/npm のパッケージ導入は不要。
- 既存の暦データ・写真 URL・写真出典・神仏案内・絵文字・日付詳細 UI・お気に入り・参拝メモ・JSON バックアップ／復元を継承する。
- 指定により削除済みの文言は再追加しない。暦の収録期間を無断変更しない。

## 2. GitHub リポジトリを作る（共通）

1. https://github.com/new を開く。
2. Repository name を `shinra-kichijitsu` にする。個人利用の APK ビルドのみなら Private でも可。無料プランで GitHub Pages を使う場合は Public を選択する。
3. README、.gitignore、License の初期生成を選択せず、空のリポジトリを作成する。
4. ZIP を展開する。`.github` を含む全ファイルを、リポジトリのルートに配置する。ZIP 自体だけをアップロードしない。

### 推奨：Git CLI で一括登録

展開したフォルダ（`web`、`android`、`.github` がある場所）で次を実行。Git と GitHub の認証設定が必要。

```sh
git init -b main
git add .
git commit -m "Initial Shinra Kichijitsu app"
git remote add origin https://github.com/YOUR_USERNAME/shinra-kichijitsu.git
git push -u origin main
```

`YOUR_USERNAME` を自分の GitHub ユーザー名に置換する。
Web UI の Add file → Upload files でも登録できるが、隠しフォルダ `.github/workflows/` が含まれているか必ず確認する。含まれない場合は Git CLI を使うか、Add file → Create new file で `.github/workflows/android.yml` と `.github/workflows/pages.yml` を同じ内容で作成する。

## 3. Android APK をビルドする

1. リポジトリの **Actions** タブを開く。Actions が無効の場合は Settings → Actions → General で使用を許可する。
2. 左側の **Android APK** を選ぶ。main への初回 push でも自動実行される。
3. 手動の場合は **Run workflow** → Branch: main → **Run workflow**。
4. 実行結果が Success（緑のチェック）になったら、その実行結果の Summary を開く。
5. Artifacts の **shinra-android-apk** をダウンロードし、ZIP を展開する。
6. `shinra-kichijitsu-debug.apk` を Android スマホに移し、ファイルアプリから開いてインストールする。端末の画面案内に従い、必要な場合だけそのファイルアプリからのインストールを許可する。
7. ホーム画面またはアプリ一覧から「森羅万象 吉日暦」を起動する。

APK は個人テスト用のデバッグ署名版。再ビルド時の署名が異なる場合は上書きできないため、事前に設定画面で参拝手帳を JSON に保存し、旧版を削除してから新しい APK をインストール・復元する。継続配布する場合は専用の署名鍵を用意し、GitHub Secrets で管理する（今回の一式に秘密鍵は含めない）。Google Play 用リリース署名や iOS IPA は対象外。

### ビルド設定（変更不要）

| 項目 | 設定 |
|---|---|
| Runner | ubuntu-24.04 |
| JDK | Temurin 17 |
| Gradle | 8.11.1 |
| Android Gradle Plugin | 8.9.2 |
| Compile SDK | 35 |
| Target SDK | 34 |
| Min SDK | 26 |
| Application ID | jp.shinra.kichijitsu |
| Build command | `gradle --no-daemon :app:assembleDebug`（android 内） |
| Artifact 保存期間 | 30日 |

Gradle Wrapper は含めず、Actions が指定バージョンの Gradle を準備する構成。PC で直接ビルドする場合は JDK 17、Gradle 8.11.1、Android SDK 35、Build Tools 35.0.0 を用意し、SDK の環境変数または `android/local.properties` を設定する。

## 4. iPhone / Android / PC 用 Web アプリを公開する

1. リポジトリの **Settings → Pages** を開く。
2. Build and deployment の Source を **GitHub Actions** にする。
3. **Actions → Publish Web App → Run workflow → main → Run workflow** を実行。
4. 成功後、Summary のデプロイ先 URL（通常 `https://YOUR_USERNAME.github.io/shinra-kichijitsu/`）を開く。
5. iPhone：Safari で共有メニュー → ホーム画面に追加。
6. Android：Chrome のメニュー → ホーム画面に追加／アプリをインストール。

`Publish Web App` は手動実行。更新時も再実行する。公開済み Web アプリの URL は他の人からもアクセスできる。端末の参拝メモはブラウザ内に保存され、GitHub へ送信されない。写真は既存の Wikimedia Commons URL から取得するため通信が必要。取得済みの画像は Web 版でキャッシュする設計。

## 5. フォルダ構成

```text
.github/workflows/android.yml   APK 自動ビルド
.github/workflows/pages.yml     Web 公開
web/index.html                  アプリ本体・暦・詳細 UI
web/manifest.webmanifest        PWA 設定
web/sw.js                       キャッシュ・オフライン
web/icon-192.png, icon-512.png   アプリアイコン
android/settings.gradle         Android プロジェクト設定
android/build.gradle            AGP 設定
android/app/build.gradle        APK 設定・Web ソース取り込み
android/app/src/main/           Manifest・Java・アイコン
scripts/check-web.mjs           ビルド前のソース検査
README.md                       この指示書
```

## 6. 動作検査・更新指示（GitHub Copilot 等への引き継ぎにも利用可）

- GitHub Actions の `Check web source` を通す。`node scripts/check-web.mjs` は JS 構文、マニフェスト、アイコン、主要 UI、14か月の年月と各日の範囲を検査する。
- Android APK を実際にインストールし、日付タップで詳細が開く、月切り替え・フィルター・寺社写真・公式サイトリンクが動く、参拝メモが保存・復元できる、戻るボタンで詳細を閉じられる、ことを確認する。
- Web 版は初回オンライン起動後、通信を切って暦の再起動を確認する。
- 暦や機能を変更する場合は `web/index.html` を編集する。Web キャッシュの更新が必要なときは `web/sw.js` の CACHE 名を更新し、Android 版の更新時は `android/app/build.gradle` の versionCode も上げる。
- ビルドエラー時は Actions の赤いステップのログを読む。SDK/Gradle 関連ならバージョンや SDK インストールの結果を確認。Pages の 403/404 なら Settings → Pages の Source、公開先環境と Actions の実行結果を確認する。

## 7. 作成時点での確認範囲

前回の暦データを継承し、暦注の日付自体を再調査したものではない。ソースの構文と構成の検査を実施。作成環境のブラウザの通信制限により Web 画面の実行テストは未完了。GitHub へのアップロード、GitHub Actions での APK ビルド、スマートフォンへのインストール、写真の実際の表示は未実施。上記の手順で検査を行う。

公式資料：
- GitHub Pages カスタムワークフロー：https://docs.github.com/ja/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages
- Android Gradle Plugin 8.9：https://developer.android.com/build/releases/agp-8-9-0-release-notes?hl=ja
- Gradle Actions：https://github.com/gradle/actions/tree/main/setup-gradle
