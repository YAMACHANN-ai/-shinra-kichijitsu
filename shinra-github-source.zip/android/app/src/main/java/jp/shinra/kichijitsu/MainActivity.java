package jp.shinra.kichijitsu;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Set;

public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String HOME = "https://" + HOST + "/index.html";
    private static final Set<String> ASSETS = new java.util.HashSet<>(java.util.Arrays.asList("index.html", "manifest.webmanifest", "icon-192.png", "icon-512.png", "sw.js"));
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private String pendingBackup;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff173e31);
        getWindow().setNavigationBarColor(0xff173e31);
        web = new WebView(this); setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false); s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportMultipleWindows(false);
        web.addJavascriptInterface(new BackupBridge(), "ShinraAndroid");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u=request.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String path=u.getPath(); String name=path==null?"":path.replaceFirst("^/", "");
                if (!"https".equals(u.getScheme()) || !ASSETS.contains(name)) return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
                String mime=name.endsWith(".png")?"image/png":name.endsWith(".html")?"text/html":name.endsWith(".js")?"application/javascript":"application/manifest+json";
                try { return new WebResourceResponse(mime, name.endsWith(".png")?null:"UTF-8", getAssets().open(name)); }
                catch(IOException e) { return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", Collections.emptyMap(), new ByteArrayInputStream(new byte[0])); }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u=request.getUrl();
                if (HOME.equals(u.toString()) && request.isForMainFrame()) return false;
                if (request.isForMainFrame() && "https".equals(u.getScheme()) && !HOST.equals(u.getHost())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW,u)); } catch (Exception ignored) {}
                }
                return true;
            }
            @Override public void onPageFinished(WebView view,String url) {
                if (!HOME.equals(url)) return;
                view.evaluateJavascript("document.getElementById('installBtn').hidden=true;document.getElementById('installHelp').textContent='Androidアプリ版を使用中です。';document.getElementById('backupBtn').onclick=()=>ShinraAndroid.saveBackup(JSON.stringify(saved,null,2));", null);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p) {
                if (chooser!=null) chooser.onReceiveValue(null);
                chooser=cb;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
                try { startActivityForResult(i,101); } catch(Exception e) { chooser.onReceiveValue(null); chooser=null; }
                return true;
            }
        });
        web.loadUrl(HOME);
    }
    public class BackupBridge {
        @JavascriptInterface public void saveBackup(String json) {
            if(json==null || json.length()>4000000) return;
            runOnUiThread(()->{ if(!HOME.equals(web.getUrl())) return; pendingBackup=json;
                Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE,"shinra-notebook.json");
                try { startActivityForResult(i,102); } catch(Exception e) { pendingBackup=null; Toast.makeText(MainActivity.this,"保存先を開けません",Toast.LENGTH_SHORT).show(); }
            });
        }
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        Uri uri=(result==RESULT_OK && data!=null)?data.getData():null;
        if(request==101 && chooser!=null) {
            chooser.onReceiveValue(null); chooser=null;
            if (uri!=null) try (InputStream in=getContentResolver().openInputStream(uri); ByteArrayOutputStream bytes=new ByteArrayOutputStream()) {
                if(in==null) throw new IOException();
                byte[] chunk=new byte[8192]; int n;
                while((n=in.read(chunk))!=-1) { if(bytes.size()+n>4000000) throw new IOException(); bytes.write(chunk,0,n); }
                String json=new String(bytes.toByteArray(), StandardCharsets.UTF_8);
                String quoted=org.json.JSONObject.quote(json).replace("\u2028", "\\u2028").replace("\u2029", "\\u2029");
                web.evaluateJavascript("document.getElementById('restoreFile').onchange({target:{files:[{text:async()=>"+quoted+"}]}})",null);
            } catch(IOException e) { Toast.makeText(this,"バックアップを読み込めません",Toast.LENGTH_SHORT).show(); }
        } else if(request==102) {
            if(uri!=null && pendingBackup!=null) try(OutputStream out=getContentResolver().openOutputStream(uri)) {
                if(out==null) throw new IOException(); out.write(pendingBackup.getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this,"バックアップを保存しました",Toast.LENGTH_SHORT).show();
            } catch(IOException e) { Toast.makeText(this,"保存に失敗しました",Toast.LENGTH_SHORT).show(); }
            pendingBackup=null;
        }
    }
    @Override public void onBackPressed() {
        web.evaluateJavascript("(()=>{const d=document.getElementById('modal');if(d&&d.open){d.close();return true}if(!document.getElementById('calendarPage').hidden)return false;switchPage('calendar');return true})()", v->{if(!"true".equals(v)) super.onBackPressed();});
    }
}
