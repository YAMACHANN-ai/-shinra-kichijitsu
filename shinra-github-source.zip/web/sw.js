const CACHE='shinra-github-v1';
const CORE=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('shinra-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;const u=new URL(e.request.url);if(u.origin!==location.origin&&u.hostname!=='upload.wikimedia.org')return;const store=async()=>{const r=await fetch(e.request);if(r.ok||r.type==='opaque'){const c=await caches.open(CACHE);await c.put(e.request,r.clone())}return r};e.respondWith(e.request.mode==='navigate'?store().catch(()=>caches.match('./index.html')):caches.match(e.request).then(r=>r||store()).catch(()=>Response.error()))});
